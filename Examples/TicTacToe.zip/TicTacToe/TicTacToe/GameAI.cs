﻿// This code was downloaded from
//      http://www.protsyk.com/cms
//    
//   Date created:
//      04 April 2008
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ScriptNET;
using System.IO;

namespace TicTacToe
{
    public class GameAI
    {
        static GameAI()
        {
            aiCode = File.ReadAllText(".\\ai.sdn");
        }

        private static string aiCode = "";
        public static ScriptContext context = new ScriptContext();

        public static int[] Field = new int[9];

        public static void MakeTurn(IInvokable SetField)
        {
            context.CreateScope();
            context.SetItem("Field", ContextItem.Variable, Field);
            Script.RunCode(aiCode, context);
            context.RemoveLocalScope();
        }

        public static int CheckWin()
        {
            if (Field[0] == Field[3] && Field[3] == Field[6] && Field[6] == Field[0] && Field[0] != 0) return Field[0];
            if (Field[1] == Field[4] && Field[4] == Field[7] && Field[7] == Field[1] && Field[1] != 0) return Field[1];
            if (Field[2] == Field[5] && Field[5] == Field[8] && Field[8] == Field[2] && Field[2] != 0) return Field[2];

            if (Field[3] == Field[4] && Field[4] == Field[5] && Field[5] == Field[3] && Field[3] != 0) return Field[3];
            if (Field[6] == Field[7] && Field[7] == Field[8] && Field[8] == Field[6] && Field[6] != 0) return Field[6];
            if (Field[0] == Field[1] && Field[1] == Field[2] && Field[2] == Field[0] && Field[0] != 0) return Field[0];

            if (Field[0] == Field[4] && Field[4] == Field[8] && Field[8] == Field[0] && Field[0] != 0) return Field[0];
            if (Field[6] == Field[4] && Field[4] == Field[2] && Field[2] == Field[6] && Field[6] != 0) return Field[6];

            return 0;
        }
    }
}
