﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using ScriptNET;

namespace TicTacToe
{
    /// <summary>
    /// Interaction logic for Window1.xaml
    /// </summary>
    public partial class Window1 : Window, IInvokable
    {
        public Window1()
        {
            InitializeComponent();
            GameAI.context.AddFunctionDefinition("SetPoint", this);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = (Button)sender;
            int count = 0;

            if (button.Content == null)
            {
                button.Content = "X";
                GameAI.Field[int.Parse((string)button.Tag)-1] = 1;

                if (GameAI.CheckWin() != 0)
                {
                    MessageBox.Show("Player wins the game", "Tic-Tac-Toe with Script.NET");
                    Restart();
                    return;
                }

                count = 0;
                for (int i = 0; i < 9; i++)
                    if (GameAI.Field[i] != 0) count++;
                if (count == 9)
                {
                    MessageBox.Show("Draw Game!", "Tic-Tac-Toe with Script.NET");
                    Restart();
                    return;
                }
                GameAI.MakeTurn(this);
                if (GameAI.CheckWin() != 0)
                {
                    MessageBox.Show("Computer Wins the game", "Tic-Tac-Toe with Script.NET");
                    Restart();
                    return;
                }
            }

            count = 0;
            for (int i = 0; i < 9; i++)
                if (GameAI.Field[i] != 0) count++;
            if (count == 9)
            {
                MessageBox.Show("Draw Game!","Tic-Tac-Toe with Script.NET");
                Restart();
                return;
            }
        }

        private bool Player = true;

        private void Restart()
        {
            for (int i = 0; i < 9; i++)
            {
                Button button = (Button)this.FindName("x" + (i + 1));
                button.Foreground = Brushes.Green;
                button.Content = null;

                GameAI.Field[i] = 0;
            }

            if (Player)
            {
                GameAI.MakeTurn(this);
            }

            Player = !Player;
        }

        #region IInvokable Members

        public bool CanInvoke()
        {
            return Visibility == Visibility.Visible;
        }

        public object Invoke(IScriptContext context, object[] args)
        {
            int index = (int)args[0];
            Button button = (Button)this.FindName("x" + (index+1));
            button.Foreground = Brushes.Red;
            button.Content = "O";

            return true;
        }

        #endregion
    }
}
