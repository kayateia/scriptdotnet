﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ScriptNET;
using ScriptNET.Runtime;

namespace ScriptNET.Tutorials.Example1
{
  class Program
  {
    static void Main(string[] args)  
    {
      //Initialize script runtime engine
      //It should be performed before compiling or executing scripts
      RuntimeHost.Initialize();

      List<int> vals = new List<int>() { 1, 2, 3, 4 };

      //Prepare compiled script for further reuse
      Script script = Script.Compile(@"
        rez = 0;
        foreach (number in numbers)
          rez += number;");

      //Supply script with an instance of .NET object
      script.Context.SetItem("numbers", vals);

      //Execute script
      object rez = script.Execute();
      Console.WriteLine(rez);

      //Clean Up runtime host after all scripts executed
      RuntimeHost.CleanUp();
      Console.ReadKey();
    }
  }
}
